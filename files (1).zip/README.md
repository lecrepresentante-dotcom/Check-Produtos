# Check Produtos

Painel de vendas para representantes comerciais — roda inteiro no navegador, sem servidor, sem instalação. Feito para analisar um histórico de faturamento (Excel) por cliente, produto, área e período.

**Link do app:** _(cole aqui o link do GitHub Pages depois de publicar, ex: `https://seu-usuario.github.io/check-produtos/`)_

## Como usar

1. Abra o link do app no navegador (computador ou celular).
2. Toque em **Importar Excel** e selecione sua planilha (`.xlsx`), com os dados na aba `BDados_Vendas`.
3. Use os filtros no topo (Período, Mês, Área, Cliente/Loja) — todos os módulos abaixo respeitam esses filtros.
4. Os dados importados e as marcações de produto ficam salvos automaticamente no navegador daquele aparelho (veja "Armazenamento" abaixo).

## Colunas esperadas na planilha

`CLIENTE/LOJA`, `NOME`, `PROD`, `DESC`, `NOTA`, `DATA`, `QUANT`, `CIDADE`, `ESTADO`, `Area`, `VLR UNIT`, `TOTAL`

## Módulos

1. **Visão gerencial** — indicadores globais, volume por mês, top clientes.
2. **Visão cliente** — detalhe de um cliente específico, histórico e comparativo.
3. **Roteiro de visitas** — sugestão de datas de visita por cidade, com exportação em PDF.
4. **Resumo executivo** — carteira ativa/inativa, frequência de compra.
5. **Marcar produtos** / **5b. Resultados por marca** — classificação manual de produtos por marca (Master, Skymix BP/PU, etc.) e análise por marca.
6. **Saúde do estoque** — produtos que pararam de ser comprados além do padrão histórico do cliente.
7. **Inteligência de vendas** — cruzamento de categorias de produto por cliente, oportunidades de venda cruzada.
8. **Ranking Top 30** — produtos mais vendidos no recorte filtrado.
9. **Curva ABC** — classificação A/B/C dos produtos por representatividade no volume.
10. **Relatório de Auditoria** — relatório completo por cliente (Curva ABC, saúde do estoque, benchmarking por região e faixa de volume, riscos e recomendações), com exportação em PDF.

## Armazenamento

Os dados importados (planilha, marcações de marca, visitas marcadas) ficam salvos via `localStorage` do navegador — ou seja, **por aparelho e por navegador**. Abrir o link no Safari do iPhone e no Chrome do computador são "memórias" separadas; cada um precisa importar a planilha uma vez.

## Publicar/atualizar

Este repositório é servido via **GitHub Pages**. Para atualizar o app:
1. Suba a nova versão de `index.html` (Add file → Upload files → Commit changes).
2. Aguarde 1–2 minutos e recarregue a página publicada (forçando recarregamento, sem cache).

## Tecnologia

Arquivo único (`index.html`), sem build/instalação. Usa [SheetJS](https://sheetjs.com/) para ler o Excel e [Chart.js](https://www.chartjs.org/) para os gráficos, carregados via CDN.
